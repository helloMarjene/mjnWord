# mjnWord — Branding record

Documents the M.A.R.J.E.N.E rebrand of upstream WordCraft 0.5.0 for every future maintainer.
The pristine upstream tree is preserved byte-identically outside this working copy, at
`MARJENE-OFFICE-DOCTOR/wordcraft-main/` (never edited).

## Product identity

- Product family: **M.A.R.J.E.N.E OFFICE DOCTOR** (M.A.R.J.E.N.E Software Development, Kampala)
- Application: **mjnWord** — desktop word processor
- Accent colour: `#D93025` (UI accent), ink `#B3261E` (readable text accent on light backgrounds)
- Shared brand palette: navy `#14213D`, white `#FFFFFF`, neutral background `#F5F7FA`,
  text `#202124` / secondary `#5F6368`
- Icon: original M.A.R.J.E.N.E tile — "M/A W" monogram in `#D93025` on a navy `#14213D`
  rounded tile (authored for this project; source SVG rendered to all icon formats)

## What was changed (user-visible identity only)

1. **Window titles** — `apps/wordcraft/src/main.rs` (`with_title`, `run_native`) and
   `crates/ui-egui/src/lib.rs` (document title suffix) now read `mjnWord`; log line too.
2. **About dialog** — `crates/ui-egui/src/dialogs.rs`: heading `mjnWord`; tagline states the
   M.A.R.J.E.N.E OFFICE DOCTOR suite + plain-text upstream attribution; links now point to
   marjenesoftwaredev.com plus the upstream GitHub source line; copyright line retained
   (ArtCraft Team and WordCraft contributors) with an added
   "Modified and distributed by M.A.R.J.E.N.E Software Development." line.
   The ArtCraft Discord links were removed (brand licence: forks must remove the marks) —
   including the "Discord" community button in the title bar and backstage, its keytip and
   ribbon command (`chrome.rs`, `backstage.rs`, `ribbon.rs`, `keytips.rs`, `lib.rs`), which now
   read "Website", use the `link` glyph and open marjenesoftwaredev.com. The internal command
   id `ui.discord` and the `app.ui.show_discord` setting key were left alone (identifier churn
   for no visible gain). Other product-name strings in `options.rs`, `file_browser.rs` and
   `zotero.rs` were re-labelled the same way.
3. **Theme accent** — `crates/ui-egui/src/theme.rs`: `APP_COLOR 0x3B5BDB → 0xD93025`,
   `APP_INK 0x2B47B5 → 0xB3261E`. These two constants do **not** cover the whole palette: the
   light "toggled" background and most of the dark accent palette are hardcoded upstream blues,
   so they were retinted too — light `checked 0xDDE3F8 → 0xFBE4E2`, dark
   `checked 0x2E3A66 → 0x4A2622`, dark `accent 0x7A93F0 → 0xF2554A`, dark `accent_text
   0x9CB0F5 → 0xFF8A80`, dark `on_accent 0x11162E → 0x2A100E` (dark ink on the light accent;
   white measures ~3:1). Text-selection tints (`selection`, both themes) intentionally stay
   blue: selection is a functional affordance where blue is the convention Word users expect,
   and a red highlight would read as a tracked change. `blue`/`red`/`green`/`orange` are
   semantic document colours and are unchanged.
4. **Icon artwork** — replaced in place (same filenames, so no identifier churn):
   `assets/app-icon/wordcraft.svg`, `wordcraft-1024.png`, `wordcraft-macos-512.png`,
   `wordcraft.ico` (9 PNG layers 16–256), `wordcraft.icns` (see caveat below), and the
   `hicolor/*` set. The Windows runtime icon comes from `hicolor/256x256`, embedded
   resources from `wordcraft.ico` via `apps/wordcraft/build.rs`.
   **Caveat:** the `.icns` is a placeholder PNG named `.icns` — it is not used by Windows
   packaging; macOS release packaging must regenerate it on macOS with
   `packaging/icons.sh` (needs resvg + iconutil) before any mac build.
5. **Windows metadata** — `apps/wordcraft/build.rs` VERSIONINFO: ProductName `mjnWord`,
   FileDescription `mjnWord word processor`, CompanyName `M.A.R.J.E.N.E Software
   Development`, LegalCopyright retained + modification notice.
6. **CLI strings** — `apps/wordcraft-cli/src/main.rs` usage header and MCP error text.
7. **Translations** — all 11 TSV catalogues in `crates/ui-egui/src/i18n/` (there is no `en.tsv`;
   English is the key itself): product-name keys
   renamed to their `mjnWord` equivalents (a TSV key **is** the English source string, so code
   `tl!` call sites and catalogue keys move together), applied by
   `MARJENE-OFFICE-DOCTOR/work/tools/rebrand-i18n.js`; ArtCraft community/discord entries
   removed; one attribution line added per locale.
   Test hooks updated: `i18n/tests.rs:610`, `i18n/audit.rs:157` exemption.
8. **Packaging** — `packaging/windows/wordcraft.wxs`: Name/Manufacturer/shortcuts/install
   folder/"Launch mjnWord"/ARP URLs → mjnWord / M.A.R.J.E.N.E Software Development; **new
   UpgradeCode** `F629E25D-CDD1-4D8B-A2B3-89396365F74D` and new component GUID (must not
   share upstream's upgrade path); a `Documentation\` folder inside the MSI carries
   README/NOTICE/ATTRIBUTION/LICENSE-mit/LICENSE-apache/BRANDING.
   `packaging/windows/package.ps1`: artifacts renamed `mjnword-<ver>-windows-<arch>.{msi,zip}`,
   licence RTF header reworded with attribution, docs copied into the portable zip.
9. **Legal files** — `NOTICE` extended with the M.A.R.J.E.N.E modification notice (original
   lines untouched); `ATTRIBUTION.md` updated to register the new icon artwork;
   `docs/brand/` (ArtCraft trademarks) deleted from this fork, as the brand licence requires.
10. **README.md** — mjnWord header, no ArtCraft promotion/community links, explicit upstream
    attribution and non-endorsement wording. Feature descriptions are unchanged from upstream, but
    four passages that would have misled a recipient of *this* package were rewritten: the
    "Downloads" section now describes the mjnword Windows x64 files and states plainly that they are
    **not code-signed** (upstream's text said "Installers and executables are code-signed"), the
    macOS/Linux/AUR tables are labelled as upstream releases only, the maturity section says
    "mjnWord is in alpha, at the same maturity as upstream" instead of pointing readers to upstream's
    downloads, and the brand-licence paragraph no longer links to `docs/brand/` (deleted here, as that
    licence requires). Runtime-troubleshooting sentences now say mjnWord.
11. **Product-name strings in engine / format writers / MCP** — swept after reading each site,
    not by blind replace: default tracked-changes author `"mjnWord User"` (`engine/src/session.rs`,
    with its test in `engine/src/tests.rs` and the i18n audit exemption), sample document creator
    and its hyperlink (`engine/src/sample.rs`), user-facing error/help text (`engine/src/io.rs`,
    `engine/src/cmd/{chart,smart_art,citations,tools}.rs`, `docx/src/crypt.rs`,
    `zotero/src/bridge.rs`), file provenance fields written into exported documents
    (`docx/src/write/mod.rs` `Application`, `formats/{html,latex,odt,rtf}.rs` generator,
    `pdf/src/lib.rs` creator/producer) and the MCP `serverInfo`/instructions (`mcp/src/server.rs`,
    `mcp/src/tools.rs`, `mcp/src/backend.rs`). `apps/wordcraft-cli/build.rs` (new) embeds the same
    icon + VERSIONINFO in `wordcraft-cli.exe`.

## What was deliberately NOT changed

- Internal identifiers: crate names `wordcraft-*`, app id `ai.storyteller.wordcraft`,
  hicolor file names, `WORDCRAFT_*` env vars, settings/storage directories, file
  extensions, protocol ids — renaming these risks breaking the MCP/CLI bridge, i18n and
  user settings for zero user-visible gain.
- Binary names `wordcraft.exe` / `wordcraft-cli.exe` (keep App Paths, shortcut targets and
  package.ps1 PE checks coherent).
- Engine logic, layout, rendering and file-format behaviour: item 11 changes only product-name
  text inside those crates, never algorithms, formats or protocols.
- Upstream copyright/licence files and third-party notices.
- No version bump in-tree: `0.5.0` remains the Cargo workspace version; the M.A.R.J.E.N.E
  release designation lives in release notes and package naming (WiX ProductVersion is numeric).

## Known branding limitations (not fixed in this Windows release)

- `packaging/macos/dmg/background.svg` still shows the upstream WordCraft wordmark (outlined
  text, so it is not a findable string) on the upstream `#3b5bdb` colour field. macOS packaging
  is out of scope here, was not rebuilt and must be re-artworked before any mac distribution.
  The same applies to `wordcraft.icns` (placeholder, see item 4).
- Text-selection highlight stays blue by design (see item 3).
- `packaging/linux/ai.storyteller.wordcraft.metainfo.xml.in` and `packaging/linux/nfpm.yaml` still
  advertise the upstream homepage (`getartcraft.com`) and Discord. They are not part of this
  Windows package and no Linux build was run here, so they were deliberately left untouched rather
  than edited blind; both must be re-branded (and the URLs replaced with
  https://marjenesoftwaredev.com) before any Linux distribution.
- `assets/spelling/en-extra.txt` keeps the word `artcraft` in the spell-check dictionary. It is a
  word list, not a product mark shown to the user, and removing it would change spell-check
  behaviour for no visible branding gain.
- `apps/wordcraft-cli/src/main.rs` prints the parity report header `# WordCraft feature parity`,
  which is written into the committed developer document `docs/parity-checklist.md`; it is build
  tooling, never shown to a user, and re- branding it would leave that document stale until
  `cargo xtask parity` is re-run, so it is left as upstream wording.

## Build reproducibility

Baseline (pre-branding): `cargo test --workspace` → 1,523 passed / 0 failed
(`work/baseline-test.log`). This copy is a git repository (initialized for this work):
commit 1 = pristine upstream; all rebrand edits are reviewable with `git diff` and revertible.
